// 配列の宣言と初期化
let scores = [74, 68, 92, 59, 77];

// 配列の長さを取得してコンソールに表示する
console.log(scores.length); // 5

// 配列の内容をコンソールに表示する
console.log(scores); // [74, 68, 92, 59, 77]

// 配列内の要素をインデックス指定してコンソールに表示する
console.log(scores[0]); // 74
console.log(scores[1]); // 68

// 配列の末尾に要素を追加してコンソールに表示する
scores.push(85);
console.log(scores); // [74, 68, 92, 59, 77, 85]

// 配列の先頭に要素を追加してコンソールに表示する
scores.unshift(90);
console.log(scores); // [90, 74, 68, 92, 59, 77, 85]

// 配列の末尾から要素を削除してコンソールに表示する
scores.pop();
console.log(scores); // [90, 74, 68, 92, 59, 77]

// 配列の先頭から要素を削除してコンソールに表示する
scores.shift();
console.log(scores); // [74, 68, 92, 59, 77]

// 実習
let fruits = ["Apple", "Banana"];
