// 変数宣言と初期化
let age = 19;

// 基本的なif文の例
if (age > 18) {
    // 条件式がtrueの場合に実行
    console.log("成人です。");
}

// 変数宣言と初期化
let temperature = 32;

// if文の例：if節とelse節を使用
if (temperature > 30) {
    // 条件がtrueの場合に実行
    console.log("It is hot outside!");
} else {
    // 条件がfalseの場合に実行
    console.log("It is not so hot outside.");
}

// 配列の宣言と初期化
let scores = [74, 68, 92, 59, 77];

// if文の例：if節，else if節，else節を使用
if (scores[0] >= 70) {
    // scoreが70以上場合に実行
    console.log("Good job!");
} else if (scores[0] >= 50) {
    // scoreが50以上70未満の場合に実行
    console.log("Passed.");
} else {
    // 上記の条件にどれも当てはまらない場合に実行
    console.log("Failed.");
}

// 変数宣言と初期化
let yourAge = 25;
let petType = "cat"; // 犬派:dog or 猫派:cat

// if文の例：if文の中にif文を入れ子にする
if (yourAge >= 18) {
    if (petType == "dog") {
        console.log("成年の犬派");
    } else {
        console.log("成年の猫派");
    }
} else {
    if (petType == "dog") {
        console.log("未成年の犬派");
    } else {
        console.log("未成年の猫派");
    }
}

// if文の例：上のif文と同じ結果となるコード
if (yourAge >= 18 && petType == "dog") {
    console.log("成年の犬派");
} else if (yourAge >= 18 && petType == "cat") {
    console.log("成年の猫派");
} else if (yourAge < 18 && petType == "cat") {
    console.log("未成年の犬派");
} else {
    console.log("未成年の猫派");
}
